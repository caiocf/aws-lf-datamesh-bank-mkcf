import boto3
import os
import time

def handler(event, context):
    glue = boto3.client('glue')
    workflow_name = os.environ['WORKFLOW_NAME']
    
    # Aguarda 30s para DMS gravar full load no S3
    time.sleep(30)
    
    run = glue.start_workflow_run(Name=workflow_name)
    print(f"Workflow {workflow_name} iniciado: {run['RunId']}")
    return {"statusCode": 200, "body": run['RunId']}
